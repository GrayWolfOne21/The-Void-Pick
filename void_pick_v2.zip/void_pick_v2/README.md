# THE VOID PICK

Local cryptocurrency mining orchestrator with a subterranean / Matrix-styled control surface.

## What this is

A Python state-machine that launches and supervises an external miner binary (XMRig, T-Rex, etc.), streams its output live to a web UI, and provides thermal protection + a hard kill switch.

**It does not contain any miner binaries.** You point it at a binary you already have.

## Requirements

- Python 3.10+ (3.8 may work with minor type-hint changes)
- A mining executable of your choice
- (Optional) Tor if you enable the SOCKS proxy feature

## Quick start

```bash
# 1. Unzip and enter
unzip void_pick_v2.zip
cd void_pick_v2

# 2. Create virtual environment
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Edit configuration
#    Set miner.binary_path and pool.user (your wallet)
nano config/void_pick.yaml

# 5. Place your miner binary (example)
#    mkdir -p miners
#    cp /path/to/xmrig miners/

# 6. Run
python -m backend.server
```

Open http://127.0.0.1:8742

## Controls

- **SEVER UPLINK** – immediately kills the miner process and enters MANUAL_HALT
- **RE-ENGAGE SYSTEM** – leaves MANUAL_HALT and restarts the state machine
- Live terminal shows raw miner stdout + FSM messages

## Project layout

```
void_pick_v2/
├── backend/
│   ├── state_machine.py   # Core FSM
│   └── server.py          # FastAPI + WebSocket
├── frontend/
│   └── index.html         # Full UI (embedded CSS/JS)
├── config/
│   └── void_pick.yaml     # All settings
├── logs/                  # Telemetry written here
├── miners/                # Put your binary here (optional)
├── requirements.txt
└── README.md
```

## Safety notes

- Mining consumes significant electricity and produces heat.
- Only run on hardware you own and are legally permitted to use.
- The kill switch and thermal throttle are provided for safety; test them.
- This software is provided as-is for educational / research use.
