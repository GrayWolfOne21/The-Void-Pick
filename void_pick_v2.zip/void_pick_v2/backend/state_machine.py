"""
THE VOID PICK - Finite State Machine
Corrected and hardened version.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from enum import Enum
from pathlib import Path
from typing import Optional, List, Any

import yaml

logger = logging.getLogger("void_pick.fsm")


class State(Enum):
    INITIALIZE = "INITIALIZE"
    EVALUATE = "EVALUATE"
    EXECUTE_MINER = "EXECUTE_MINER"
    VOID_DREDGE = "VOID_DREDGE"
    MONITOR = "MONITOR"
    THERMAL_THROTTLE = "THERMAL_THROTTLE"
    MANUAL_HALT = "MANUAL_HALT"
    DATA_LOGGING = "DATA_LOGGING"


class VoidPickFSM:
    def __init__(self, config_path: str | Path, ws_manager: Any):
        self.config_path = Path(config_path).resolve()
        self.config = self._load_config()
        self.ws_manager = ws_manager

        self.state = State.INITIALIZE
        self.miner_process: Optional[asyncio.subprocess.Process] = None
        self.is_halted = False
        self.current_temp = 0.0
        self.hashrate = 0.0
        self.accepted_shares = 0
        self.rejected_shares = 0
        self.last_eval_ts = 0.0
        self._shadow_task: Optional[asyncio.Task] = None
        self._stdout_tasks: List[asyncio.Task] = []

        # Ensure log directory exists
        log_dir = Path(self.config.get("logging", {}).get("log_dir", "./logs"))
        log_dir.mkdir(parents=True, exist_ok=True)
        self.log_dir = log_dir

    def _load_config(self) -> dict:
        if not self.config_path.exists():
            logger.warning("Config not found at %s – using safe defaults", self.config_path)
            return self._default_config()
        with open(self.config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        # Merge with defaults so missing keys don't crash
        defaults = self._default_config()
        for section, values in defaults.items():
            if section not in data:
                data[section] = values
            elif isinstance(values, dict):
                for k, v in values.items():
                    data[section].setdefault(k, v)
        return data

    @staticmethod
    def _default_config() -> dict:
        return {
            "miner": {
                "binary_path": "./miners/xmrig",
                "algorithm": "rx/0",
            },
            "pool": {
                "url": "stratum+tcp://pool.supportxmr.com:443",
                "user": "YOUR_WALLET_ADDRESS",
                "password": "x",
                "worker": "void_node_01",
            },
            "hardware": {
                "max_temp_celsius": 85,
                "temp_sensor_path": "/sys/class/thermal/thermal_zone0/temp",
            },
            "advanced": {
                "shadow_routing": True,
                "void_dredge_enabled": False,
                "void_dredge_threshold": 10.0,
                "prefer_stratum_v2": False,
                "pool_weight_multiplier": 1.0,
                "use_tor_proxy": False,
                "tor_proxy_address": "socks5://127.0.0.1:9050",
                "edge_trimming": False,
            },
            "logging": {
                "log_dir": "./logs",
                "log_level": "INFO",
            },
        }

    async def broadcast(self, msg: str) -> None:
        line = f"[{self.state.value}] {msg}"
        logger.info(line)
        if self.ws_manager:
            try:
                await self.ws_manager.broadcast(line + "\n")
            except Exception as e:
                logger.debug("Broadcast failed: %s", e)

    async def run(self) -> None:
        await self.broadcast("FSM started.")
        while True:
            try:
                if self.is_halted and self.state != State.MANUAL_HALT:
                    self.state = State.MANUAL_HALT

                await self._execute_state()
                await asyncio.sleep(1.0)
            except asyncio.CancelledError:
                await self._safe_kill_miner()
                raise
            except Exception as e:
                logger.exception("FSM error in %s", self.state.value)
                await self.broadcast(f"CRITICAL ERROR: {e}")
                await asyncio.sleep(5)

    async def _execute_state(self) -> None:
        handlers = {
            State.INITIALIZE: self._initialize,
            State.EVALUATE: self._evaluate,
            State.EXECUTE_MINER: self._execute_miner,
            State.VOID_DREDGE: self._void_dredge,
            State.MONITOR: self._monitor,
            State.THERMAL_THROTTLE: self._thermal_throttle,
            State.MANUAL_HALT: self._manual_halt,
            State.DATA_LOGGING: self._data_logging,
        }
        handler = handlers.get(self.state)
        if handler:
            await handler()

    # ------------------------------------------------------------------
    # State implementations
    # ------------------------------------------------------------------

    async def _initialize(self) -> None:
        await self.broadcast("Initializing subsystems...")
        bin_path = Path(self.config["miner"]["binary_path"])
        if not bin_path.exists():
            await self.broadcast(
                f"WARNING: Miner binary not found at {bin_path}. "
                "Running in simulation / dry-run mode."
            )
        else:
            await self.broadcast(f"Miner binary located: {bin_path}")
        await self.broadcast("Initialization complete → EVALUATE")
        self.state = State.EVALUATE

    async def _evaluate(self) -> None:
        await self.broadcast("Evaluating profitability / network conditions...")
        # Placeholder for real API calls (WhatToMine, Minerstat, custom)
        await asyncio.sleep(1.5)

        if self.config["advanced"].get("shadow_routing", True):
            if self._shadow_task is None or self._shadow_task.done():
                self._shadow_task = asyncio.create_task(self._shadow_evaluate())

        self.last_eval_ts = time.time()
        self.state = State.EXECUTE_MINER

    async def _shadow_evaluate(self) -> None:
        """Runs concurrently; does not stop the active miner."""
        await self.broadcast("Shadow evaluation running in background...")
        await asyncio.sleep(8)
        await self.broadcast("Shadow evaluation complete – no route change required.")

    async def _execute_miner(self) -> None:
        if self.miner_process and self.miner_process.returncode is None:
            self.state = State.MONITOR
            return

        await self.broadcast("Spawning miner process...")
        cmd = self._build_miner_command()
        await self.broadcast(f"Command: {' '.join(cmd[:6])} ...")

        bin_path = Path(cmd[0])
        if not bin_path.exists():
            await self.broadcast("Binary missing – entering simulated MONITOR loop.")
            self.state = State.MONITOR
            return

        try:
            self.miner_process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            # Cancel any previous stream tasks
            for t in self._stdout_tasks:
                t.cancel()
            self._stdout_tasks = [
                asyncio.create_task(self._stream_output(self.miner_process.stdout))
            ]
            await self.broadcast("Miner process started.")
            self.state = State.MONITOR
        except Exception as e:
            await self.broadcast(f"Failed to start miner: {e}")
            await asyncio.sleep(5)
            # Stay in EXECUTE_MINER so we retry

    def _build_miner_command(self) -> List[str]:
        cfg = self.config
        miner_cfg = cfg["miner"]
        pool_cfg = cfg["pool"]
        adv = cfg["advanced"]

        cmd = [
            str(miner_cfg["binary_path"]),
            "-a", miner_cfg.get("algorithm", "rx/0"),
            "-o", pool_cfg["url"],
            "-u", pool_cfg["user"],
            "-p", pool_cfg.get("password", "x"),
        ]

        if adv.get("prefer_stratum_v2"):
            cmd.append("--stratum-v2")  # stub – real flag depends on miner

        if adv.get("use_tor_proxy"):
            proxy = adv.get("tor_proxy_address", "socks5://127.0.0.1:9050")
            cmd.append(f"--proxy={proxy}")

        if adv.get("edge_trimming") and miner_cfg.get("algorithm", "") in (
            "kawpow", "firopow", "cuckatoo", "cuckaroo"
        ):
            cmd.append("--edge-trim")  # stub

        return cmd

    async def _stream_output(self, stream) -> None:
        if stream is None:
            return
        try:
            while True:
                line = await stream.readline()
                if not line:
                    break
                text = line.decode("utf-8", errors="replace").rstrip()
                if text:
                    await self.ws_manager.broadcast(text + "\n")
                    # Very light parsing
                    lower = text.lower()
                    if "accepted" in lower:
                        self.accepted_shares += 1
                    elif "rejected" in lower:
                        self.rejected_shares += 1
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.debug("Stream reader stopped: %s", e)

    async def _void_dredge(self) -> None:
        await self.broadcast("VOID_DREDGE engaged – targeting low-difficulty residual value.")
        # Real implementation would swap algorithm/pool here
        await asyncio.sleep(3)
        self.state = State.MONITOR

    async def _monitor(self) -> None:
        self.current_temp = self._read_temperature()

        max_temp = self.config["hardware"].get("max_temp_celsius", 85)
        if self.current_temp > max_temp:
            self.state = State.THERMAL_THROTTLE
            return

        if self.config["advanced"].get("void_dredge_enabled"):
            # Placeholder difficulty check
            dummy_difficulty = 5.0
            threshold = self.config["advanced"].get("void_dredge_threshold", 10.0)
            if dummy_difficulty < threshold:
                self.state = State.VOID_DREDGE
                return

        # Periodic telemetry
        if int(time.time()) % 30 == 0:
            self.state = State.DATA_LOGGING
            return

        # Stay in MONITOR
        await asyncio.sleep(0.5)

    def _read_temperature(self) -> float:
        sensor = self.config["hardware"].get("temp_sensor_path")
        if sensor and Path(sensor).exists():
            try:
                raw = Path(sensor).read_text().strip()
                # Most hwmon sensors report millidegrees
                return int(raw) / 1000.0
            except Exception:
                pass
        # Fallback mock – slowly varying
        return 48.0 + (time.time() % 20)

    async def _thermal_throttle(self) -> None:
        await self.broadcast(
            f"THERMAL LIMIT EXCEEDED ({self.current_temp:.1f}°C). "
            "Throttling / pausing miner."
        )
        await self._safe_kill_miner()

        recovery = self.config["hardware"].get("max_temp_celsius", 85) - 8
        while self.current_temp > recovery:
            await asyncio.sleep(4)
            self.current_temp = self._read_temperature()
            await self.broadcast(f"Cooling... current {self.current_temp:.1f}°C")

        await self.broadcast("Temperatures recovered → returning to EVALUATE")
        self.state = State.EVALUATE

    async def _manual_halt(self) -> None:
        await self.broadcast("MANUAL_HALT – uplink severed. Waiting for re-engage.")
        await self._safe_kill_miner()
        # Stay here until re_engage() is called
        await asyncio.sleep(1.0)

    async def _data_logging(self) -> None:
        log_file = self.log_dir / "void_telemetry.log"
        line = (
            f"{time.strftime('%Y-%m-%d %H:%M:%S')} | "
            f"STATE={self.state.value} | TEMP={self.current_temp:.1f}C | "
            f"ACC={self.accepted_shares} REJ={self.rejected_shares}\n"
        )
        try:
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception as e:
            logger.warning("Failed to write telemetry: %s", e)
        self.state = State.MONITOR

    async def _safe_kill_miner(self) -> None:
        if self.miner_process and self.miner_process.returncode is None:
            try:
                self.miner_process.terminate()
                await asyncio.wait_for(self.miner_process.wait(), timeout=4.0)
            except Exception:
                try:
                    self.miner_process.kill()
                except Exception:
                    pass
            self.miner_process = None
            await self.broadcast("Miner process terminated.")

    # ------------------------------------------------------------------
    # External control
    # ------------------------------------------------------------------

    def sever_uplink(self) -> None:
        self.is_halted = True
        logger.warning("Kill switch activated")

    def re_engage(self) -> None:
        self.is_halted = False
        self.state = State.INITIALIZE
        logger.info("Re-engage requested")

    def get_status(self) -> dict:
        return {
            "state": self.state.value,
            "temp_c": round(self.current_temp, 1),
            "hashrate": self.hashrate,
            "accepted": self.accepted_shares,
            "rejected": self.rejected_shares,
            "halted": self.is_halted,
            "binary_exists": Path(self.config["miner"]["binary_path"]).exists(),
        }
