"""
THE VOID PICK - FastAPI server + WebSocket terminal
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

from state_machine import VoidPickFSM

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("void_pick.server")

# Resolve project root (one level up from backend/)
ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config" / "void_pick.yaml"
FRONTEND_DIR = ROOT / "frontend"


class ConnectionManager:
    def __init__(self) -> None:
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info("Client connected (%d total)", len(self.active_connections))

    def disconnect(self, websocket: WebSocket) -> None:
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        logger.info("Client disconnected (%d total)", len(self.active_connections))

    async def broadcast(self, message: str) -> None:
        dead: List[WebSocket] = []
        for connection in self.active_connections:
            try:
                await connection.send_text(message)
            except Exception:
                dead.append(connection)
        for conn in dead:
            self.disconnect(conn)


manager = ConnectionManager()
fsm: VoidPickFSM | None = None
fsm_task: asyncio.Task | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global fsm, fsm_task
    fsm = VoidPickFSM(CONFIG_PATH, manager)
    fsm_task = asyncio.create_task(fsm.run())
    logger.info("Void Pick FSM launched")
    yield
    if fsm_task:
        fsm_task.cancel()
        try:
            await fsm_task
        except asyncio.CancelledError:
            pass
    if fsm:
        await fsm._safe_kill_miner()
    logger.info("Shutdown complete")


app = FastAPI(title="THE VOID PICK", version="0.2.0", lifespan=lifespan)


@app.websocket("/ws/terminal")
async def websocket_terminal(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # Keep alive; client can send "ping"
            data = await websocket.receive_text()
            if data.strip().lower() == "ping":
                await websocket.send_text("pong\n")
    except WebSocketDisconnect:
        manager.disconnect(websocket)


@app.post("/api/sever_uplink")
async def sever_uplink():
    if fsm:
        fsm.sever_uplink()
    return {"status": "UPLINK_SEVERED"}


@app.post("/api/re_engage")
async def re_engage():
    if fsm:
        fsm.re_engage()
    return {"status": "RE_ENGAGED"}


@app.get("/api/status")
async def status():
    if fsm:
        return fsm.get_status()
    return JSONResponse({"error": "FSM not ready"}, status_code=503)


@app.get("/")
async def index():
    return FileResponse(FRONTEND_DIR / "index.html")


# Optional: serve any extra static assets if added later
if (FRONTEND_DIR / "static").exists():
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR / "static"), name="static")


if __name__ == "__main__":
    uvicorn.run(
        "server:app",
        host="127.0.0.1",
        port=8742,
        reload=False,
        log_level="info",
    )
